
const API_KEY = "YOUR_API_KEY"; // Replace with your real API key

async function getWeather() {
  const city = document.getElementById("cityInput").value;
  const res = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`);
  const data = await res.json();
  
  document.getElementById("weatherResult").innerHTML = `
    <h2>Current Weather in ${data.name}</h2>
    <p>🌡️ Temp: ${data.main.temp}°C</p>
    <p>🌥️ Condition: ${data.weather[0].main}</p>
  `;

  const forecastRes = await fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${API_KEY}&units=metric`);
  const forecastData = await forecastRes.json();
  
  let forecastHTML = "<h2>5-Day Forecast:</h2><ul>";
  for (let i = 0; i < forecastData.list.length; i += 8) {
    let f = forecastData.list[i];
    forecastHTML += `
      <li>
        📅 ${f.dt_txt.split(" ")[0]} – ${f.main.temp}°C, ${f.weather[0].main}
      </li>
    `;
  }
  forecastHTML += "</ul>";
  document.getElementById("forecastResult").innerHTML = forecastHTML;
}
