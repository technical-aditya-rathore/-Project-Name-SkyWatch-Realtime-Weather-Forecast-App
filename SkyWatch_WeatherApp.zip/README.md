
# SkyWatch – Weather & Forecast App

🌦️ A simple weather app that displays current weather and 5-day forecast using OpenWeatherMap API.

## Features
- Realtime weather by city
- 5-day forecast
- Responsive & clean design

## Setup
1. Get an API key from [OpenWeatherMap](https://openweathermap.org/api)
2. Replace `"YOUR_API_KEY"` in `script.js` with your key

## Owner & License

🔒 This project is developed and owned by **Aditya Kumar Jha**.  
Unauthorized copying, reproduction, or reuse of this code is strictly prohibited. Legal action will be taken under GitHub and copyright policies.

© 2025 Aditya Kumar Jha. All rights reserved.
